package Employeee;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.sql.ResultSet;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import javax.swing.border.MatteBorder;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JTextField;
import javax.swing.ImageIcon;

public class Students extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table_1;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Students frame = new Students();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Students() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 903, 368);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 21, 849, 125);
		contentPane.add(scrollPane);
		
		table_1 = new JTable();
		table_1.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(255, 51, 51)));
		table_1.setColumnSelectionAllowed(true);
		table_1.setCellSelectionEnabled(true);
		table_1.setBackground(new Color(204, 255, 255));
		table_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		scrollPane.setViewportView(table_1);
		
		try {
			conn con = new conn();
            String str2 = "select * from STUDENTS_DATA";
            ResultSet rs1= con.s.executeQuery(str2);
			table_1.setModel(new DefaultTableModel(
				new Object[][] {
					{"MON", "SRK 208", "VM,DB 208", "DR.LHK 208", "MNP 208", "LUNCH", "RAK 208", "JK 208", "ONR 208", "CSE2D"},
					{"TUE", "JK 208", "MNP BELL LAB", "MNP BELL LAB", "MNP BELL LAB", "LUNCH", "SRK 208", "MNP 208", "DR.LHK 208", "CSE2D"},
					{"WED", "MNP 208 ", "ONR 208", "RAK 208", "JK 208", "LUNCH", "SRK 208", "DR.LHK 208", "VM 208", "CSE2D"},
					{"THU", "ONR 208", "MNP 208", "RAK 208", "SRK 208", "LUNCH", "ONR SILLICON LAB", "ONR SILLICON LAB", "ONR SILLICON LAB", "CSE2D"},
					{"FRI", "DR.LHK 208", "SRK NEUMANN LAB", "SRK NEUMANN LAB", "SRK NEUMANN LAB", "LUNCH", "RAK 208", "ONR 208", "JK 208", "CSE2D"},
					{"SAT", "RAK 208", "SRK 208", "ONR 208", "DR.LHK 208", "LUNCH", "JK 208", "SRK 208", "MNP 208", "CSE2D"},
					{"MON", "MSPK 207", "SAB SILICON LAB", "SAB SILICON LAB", "SAB SILICON LAB", "LUNCH", "CVLN 207", "SAB 207", "DR.PR 207", "CSE2C"},
					{"TUE", "DR.PR 207 ", "MSPK 207", "JK.SMR 207", "SAB 207", "LUNCH", "KUKR 207", "CSD 207", "JK.BPRR 207", "CSE2C"},
					{"WED", "CSD 207", "KUKR BELL LAB", "KUKR BELL LAB", "KUKR BELL LAB", "LUNCH", "SAB 207", "KUKR 207", "CVLN 207", "CSE2C"},
					{"THU", "KUKR 207", "CVLN 207", "CSD 207", "DR.PR 207", "LUNCH", "CVLN NEUMANN LAB", "CVLN NEUMANN LAB", "CVLN NEUMANN LAB", "CSE2C"},
					{"FRI", "CVLN 207", "CSD 207", "DR.PR 207", "KUKR 207", "LUNCH", "MSPK 207", "CVLN 207", "SAB 207", "CSE2C"},
					{"SAT", "SAB 207", "CVLN 207", "MSPK 207", "CSD 207", "LUNCH", "DR.PR 207", "MSPK 207", "KUKR 207", "CSE2C"},
				},
				new String[] {
					"Days", "1[9.15-10.10]", "2[10.10-11.05]", "3[11.05-12.00]", "4[12.00-12.55]", "LUNCH", "5[2.00-2.55]", "6[2.55-3.50]", "7[3.50-5.00]", "Class_ID"
				}
			));
			
			JLabel lblNewLabel = new JLabel("Search Class_ID");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
			lblNewLabel.setBounds(24, 175, 135, 14);
			contentPane.add(lblNewLabel);
			
			JTextArea HELLO = new JTextArea();
			HELLO.addKeyListener(new KeyAdapter() {
				@Override
				public void keyReleased(KeyEvent e) {
					
					try {
						conn con = new conn();
			            String str = "select * from STUDENTS_DATA where Class_ID='"+HELLO.getText()+"'";
			            ResultSet rs= con.s.executeQuery(str);
						table_1.setModel(DbUtils.resultSetToTableModel(rs));
						
					}
					catch(Exception e1) {
						e1.printStackTrace();
					}
				}
			});
			HELLO.setBackground(new Color(204, 255, 255));
			HELLO.setBounds(169, 171, 96, 22);
			contentPane.add(HELLO);
			
			textField = new JTextField();
			textField.addKeyListener(new KeyAdapter() {
				@Override
				public void keyReleased(KeyEvent e) {
					try {
						conn con = new conn();
			            String str = "select * from STUDENTS_DATA where Days='"+textField.getText()+"'";
			            ResultSet rs= con.s.executeQuery(str);
						table_1.setModel(DbUtils.resultSetToTableModel(rs));
						
					}
					catch(Exception e1) {
						e1.printStackTrace();
					}
					
				}
			});
			textField.setBackground(new Color(204, 255, 255));
			textField.setBounds(169, 209, 96, 20);
			contentPane.add(textField);
			textField.setColumns(10);
			
			JLabel lblNewLabel_1 = new JLabel("New label");
			lblNewLabel_1.setIcon(new ImageIcon(Students.class.getResource("/Employeee/simple-background-backgrounds-passion-simple-1-5c9b95c3a34f9.png")));
			lblNewLabel_1.setBounds(0, 0,1500,720);
			contentPane.add(lblNewLabel_1);
			table_1.getColumnModel().getColumn(2).setPreferredWidth(83);
			table_1.getColumnModel().getColumn(3).setPreferredWidth(84);
			table_1.getColumnModel().getColumn(4).setPreferredWidth(90);
			table_1.getColumnModel().getColumn(6).setPreferredWidth(93);
			table_1.getColumnModel().getColumn(7).setPreferredWidth(87);
			table_1.getColumnModel().getColumn(8).setPreferredWidth(90);
			
		}
		catch(Exception e1) {
			e1.printStackTrace();
		}
		

}
}
