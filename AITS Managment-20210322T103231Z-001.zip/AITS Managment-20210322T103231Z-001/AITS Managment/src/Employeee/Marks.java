package Employeee;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;

public class Marks extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JTable table_2;
	private JTable table_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Marks frame = new Marks();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Marks() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 848, 465);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel bg = new JPanel();
		bg.setBounds(0, 0, 832, 426);
		contentPane.add(bg);
		bg.setLayout(null);
		
		JPanel sidebar = new JPanel();
		sidebar.setBackground(new Color(0, 0, 0));
		sidebar.setBounds(0, 0, 259, 426);
		bg.add(sidebar);
		sidebar.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
	            new login();
				
				//Front_Page f = new Front_Page();
			}
		});
		panel.setBounds(0, 113, 259, 33);
		panel.setBackground(new Color(25, 25, 112));
		sidebar.add(panel);
		panel.setLayout(null);
		
		JLabel image = new JLabel("");
		image.setIcon(new ImageIcon(Marks.class.getResource("/Employeee/home.png")));
		image.setBounds(10, 0, 46, 33);
		panel.add(image);
		
		JLabel lblNewLabel = new JLabel("Marks");
		lblNewLabel.setForeground(new Color(248, 248, 255));
		lblNewLabel.setFont(new Font("Serif", Font.BOLD, 20));
		lblNewLabel.setBounds(69, 0, 180, 33);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		panel_1.setBounds(0, 157, 259, 33);
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(25, 25, 112));
		sidebar.add(panel_1);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(Marks.class.getResource("/Employeee/fancy-rings-motion-background-flat-design-4k-and-full-hd-blue_htrkjm1f__F0003.png")));
		label.setBounds(10, 0, 46, 33);
		panel_1.add(label);
		
		JLabel lblIyear = new JLabel("I-Year");
		lblIyear.setForeground(new Color(248, 248, 255));
		lblIyear.setFont(new Font("Serif", Font.BOLD, 20));
		lblIyear.setBounds(69, 0, 180, 33);
		panel_1.add(lblIyear);
		
		JPanel panel_2 = new JPanel();
		panel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		panel_2.setBounds(0, 201, 259, 33);
		panel_2.setLayout(null);
		panel_2.setBackground(new Color(25, 25, 112));
		sidebar.add(panel_2);
		
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(Marks.class.getResource("/Employeee/images.jpg")));
		label_2.setBounds(10, 0, 46, 33);
		panel_2.add(label_2);
		
		JLabel lblIiyear = new JLabel("II-Year");
		lblIiyear.setForeground(new Color(248, 248, 255));
		lblIiyear.setFont(new Font("Serif", Font.BOLD, 20));
		lblIiyear.setBounds(69, 0, 180, 33);
		panel_2.add(lblIiyear);
		
		JPanel panel_3 = new JPanel();
		panel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		panel_3.setBounds(0, 245, 259, 33);
		panel_3.setLayout(null);
		panel_3.setBackground(new Color(25, 25, 112));
		sidebar.add(panel_3);
		
		JLabel label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon(Marks.class.getResource("/Employeee/pngtree-employee-icon-vector-illustration-in-glyph-style-for-any-purpose-png-image_4257910.jpg")));
		label_4.setBounds(10, 0, 46, 33);
		panel_3.add(label_4);
		
		JLabel lblIiiyear = new JLabel("III-Year");
		lblIiiyear.setForeground(new Color(248, 248, 255));
		lblIiiyear.setFont(new Font("Serif", Font.BOLD, 20));
		lblIiiyear.setBounds(69, 0, 180, 33);
		panel_3.add(lblIiiyear);
		
		JPanel panel_4 = new JPanel();
		panel_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			}
		});
		panel_4.setBounds(0, 289, 259, 33);
		panel_4.setLayout(null);
		panel_4.setBackground(new Color(25, 25, 112));
		sidebar.add(panel_4);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(Marks.class.getResource("/Employeee/form.jpg")));
		label_1.setBounds(10, 0, 46, 33);
		panel_4.add(label_1);
		
		JLabel lblIvyear = new JLabel("IV-Year");
		lblIvyear.setForeground(new Color(248, 248, 255));
		lblIvyear.setFont(new Font("Serif", Font.BOLD, 20));
		lblIvyear.setBounds(69, 0, 180, 33);
		panel_4.add(lblIvyear);
		
		JLabel lblNewLabel_1 = new JLabel("AITS");
		lblNewLabel_1.setForeground(new Color(248, 248, 255));
		lblNewLabel_1.setFont(new Font("Serif", Font.BOLD, 35));
		lblNewLabel_1.setBounds(74, 29, 159, 45);
		sidebar.add(lblNewLabel_1);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBounds(260, 0, 572, 426);
		bg.add(panel_5);
		panel_5.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(35, 100, 510, 293);
		panel_5.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(35, 99, 508, 293);
		panel_5.add(scrollPane_1);
		
		table_1 = new JTable();
		scrollPane_1.setViewportView(table_1);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(35, 100, 510, 293);
		panel_5.add(scrollPane_2);
		
		table_2 = new JTable();
		scrollPane_2.setViewportView(table_2);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(35, 101, 510, 293);
		panel_5.add(scrollPane_3);
		
		table_3 = new JTable();
		scrollPane_3.setViewportView(table_3);
		
		JPanel home = new JPanel();
		home.addPropertyChangeListener(new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent arg0) {
				new login();
			}
		});
		home.setBounds(0, 0, 562, 426);
		panel_5.add(home);
	}
}
