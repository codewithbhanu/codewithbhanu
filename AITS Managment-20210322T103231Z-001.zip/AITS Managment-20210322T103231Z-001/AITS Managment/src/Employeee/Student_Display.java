package Employeee;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.sql.ResultSet;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Student_Display extends JFrame {
	JFrame f;
	 String Name,Class_ID,Course,Year,DOB,HT_NO,Age,Address;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student_Display frame = new Student_Display("Student_Display");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student_Display(String s_id) {
		try{
            conn con = new conn();
            String str = "select * from Studentall where HT_NO = '"+s_id+"'";
            ResultSet rs= con.s.executeQuery(str);

            while(rs.next()){

               
                Name = rs.getString("Name");
                HT_NO = rs.getString("HT_NO");
                Course = rs.getString("Course");
                Year = rs.getString("Year");
                Class_ID = rs.getString("Class_ID");
                Age = rs.getString("Age");
                DOB = rs.getString("DOB");
                Address = rs.getString("Address");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 472, 585);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Student ID:");
		lblNewLabel.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel.setBounds(23, 59, 105, 14);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_3 = new JLabel(HT_NO);
		lblNewLabel_3.setBounds(159, 59, 211, 20);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_1 = new JLabel("Name:");
		lblNewLabel_1.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_1.setBounds(23, 117, 105, 20);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel(Name);
		lblNewLabel_2.setBounds(159, 120, 211, 20);
		getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_4 = new JLabel("Course:");
		lblNewLabel_4.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_4.setBounds(23, 175, 105, 20);
		getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel(Course);
		lblNewLabel_5.setBounds(159, 175, 211, 20);
		getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Year:");
		lblNewLabel_6.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_6.setBounds(23, 231, 105, 20);
		getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel(Year);
		lblNewLabel_7.setBounds(159, 231, 211, 20);
		getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Class_ID:");
		lblNewLabel_8.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_8.setBounds(23, 285, 105, 20);
		getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel(Class_ID);
		lblNewLabel_9.setBounds(159, 285, 211, 20);
		getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Age:");
		lblNewLabel_10.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_10.setBounds(23, 338, 105, 20);
		getContentPane().add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel(Age);
		lblNewLabel_11.setBounds(159, 338, 211, 20);
		getContentPane().add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("Date of Birth:");
		lblNewLabel_12.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_12.setBounds(23, 394, 105, 20);
		getContentPane().add(lblNewLabel_12);
		
		JLabel lblNewLabel_13 = new JLabel(DOB);
		lblNewLabel_13.setBounds(159, 394, 211, 20);
		getContentPane().add(lblNewLabel_13);
		
		JLabel lblNewLabel_14 = new JLabel("Address:");
		lblNewLabel_14.setFont(new Font("Serif", Font.BOLD, 18));
		lblNewLabel_14.setBounds(23, 442, 105, 20);
		getContentPane().add(lblNewLabel_14);
		
		JLabel lblNewLabel_15 = new JLabel(Address);
		lblNewLabel_15.setBounds(154, 442, 216, 20);
		getContentPane().add(lblNewLabel_15);
		
		JButton btnNewButton = new JButton("Monitoring");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//f.setVisible(false);
				Students s=new Students();
				s.setVisible(true);
				
                //s.f.setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setBounds(76, 500, 124, 23);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Cancel");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				View_Student d=new View_Student();
				d.f.setVisible(true);
				//d.f.setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1.setBounds(267, 500, 103, 23);
		getContentPane().add(btnNewButton_1);
	}
}
