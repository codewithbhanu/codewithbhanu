package Employeee;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import com.sun.jdi.connect.spi.Connection;

import net.proteanit.sql.DbUtils;
import java.awt.Color;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import javax.swing.border.TitledBorder;
import java.awt.Toolkit;
import javax.swing.border.BevelBorder;
import javax.swing.ImageIcon;

public class Hello extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	protected JComponent f;
	private JTextField textFieldsearch;
	private JTextField field;
	private JTextField Field1;
	private JLabel lblNewLabel_1;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Hello frame = new Hello();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @param string 
	 */
	public Hello() {
		setBackground(Color.WHITE);
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Bhanu248\\Downloads\\annamacharya-institute-of-technology-and-sciences-aits-rajampet.jpg"));
		setTitle("CSE_FACULTY");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1260, 543);
		contentPane = new JPanel();
		contentPane.setForeground(Color.BLACK);
		contentPane.setBackground(new Color(255, 228, 225));
		contentPane.setBorder(UIManager.getBorder("MenuBar.border"));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 1216, 136);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setBackground(new Color(204, 255, 255));
		table.setBorder(UIManager.getBorder("Button.border"));
		table.setFont(new Font("Tahoma", Font.BOLD, 12));
		scrollPane.setViewportView(table);
		
		try {
			conn con = new conn();
            String str = "select * from CSE_FACULTY";
            ResultSet rs= con.s.executeQuery(str);
			table.setModel(new DefaultTableModel(
				new Object[][] {
					{"FRI", "", "", "", "", "", "OOAD 3CS-C", "", "Aits051001", "MRK"},
					{"MON", "", "", "OOAD 3CS-C", "", "", "", "", "Aits051001", "MRK"},
					{"SAT", "", "", "", "", "", "", "", "Aits051001", "MRK"},
					{"THU", "", "OOAD 3CS-C", "", "", "OS LAB 2CS-D", "OS LAB 2CS-D", "OS LAB 2CS-D", "Aits051001", "MRK"},
					{"TUE", "", "ST&CTL LAB 3CS-C,SILICON LAB", "ST&CTL LAB 3CS-C,SILICON LAB", "ST&CTL LAB 3CS-C,SILICON LAB", "", "OOAD 3CS-C", "", "Aits051001", "MRK"},
					{"WED", "", "OOAD 3CS-C", "", "", "", "", "", "Aits051001", "MRK"},
					{"MON", "", "", "SA 4 CS-B", "", "OOPC LAB 3 EEE-B", "OOPC LAB 3 EEE-B", "OOPC LAB 3 EEE-B", "Aits051002", "PCSM"},
					{"TUE", "SA 4 CS-B", "", "", "SA 4 CS-B", "", "", "STM 3 CS-B", "Aits051002", "PCSM"},
					{"WED", "", "SA 4 CS-B", "SA 4 CS-B", "", "STM 3 CS-B", "", "OOAD* 3 CS-A", "Aits051002", "PCSM"},
					{"THU", "", "", "", "STM 3CS-B", "CO* 2CS-A", "", "", "Aits051002", "PCSM"},
					{"FRI", "STM 3CS-B", "", "", "DAA* 2CS-C", "ST&CT LAB 3CS-B L2", "ST&CT LAB 3CS-B L3", "ST&CT LAB 3CS-B L4", "Aits051002", "PCSM"},
					{"SAT", "AIT W/S I CSE-A IOT", "AIT W/S I CSE-A IOT", "AIT W/S I CSE-A IOT", "", "", "STM 3CS-B", "", "Aits051002", "PCSM"},
					{"MON", "", "MC 4 IT", "", "", "SEM 4 IT", "SEM 4 IT", "", "Aits051003", "kp"},
					{"TUE", "MC 4 IT", "", "", "MC 4 IT", "", "", "", "Aits051003", "kp"},
					{"WED", "", "", "MC 4 IT", "", "DAA LAB 3 CS-C", "DAA LAB 3 CS-C", "DAA LAB 3 CS-C", "Aits051003", "kp"},
					{"THU", "", "", "", "", "DM LAB 3 CS-C", "DM LAB 3 CS-C", "DM LAB 3 CS-C", "Aits051003", "kp"},
					{"FRI", "", "", "", "", "", "", "", "Aits051003", "kp"},
					{"SAT", "", "", "", "", "", "", "", "Aits051003", "kp"},
					{"MON", "OOAD 3 CS-A", "JAVA LAB 2 CS-A,NEUMANN", "JAVA LAB 2 CS-A,NEUMANN", "JAVA LAB 2 CS-A,NEUMANN", "", "CO 2 CS-D", "", "Aits051004", "D.JK"},
					{"TUE", "CO 2 CS-D", "", "SEM 2 CSE-C", "", "OOAD 3 CS-A", "", "SEM 2CS-C", "Aits051004", "D.JK"},
					{"WED", "", "", "", "CO 2 CS-D", "", "", "OOAD 3 CS-A", "Aits051004", "D.JK"},
					{"THU", "", "OOAD 3 CS-A", "", "", "JAVA LAB 3 CS-C NEUMANN", "JAVA LAB 3 CS-C NEUMANN", "JAVA LAB 3 CS-C NEUMANN", "Aits051004", "D.JK"},
					{"FRI", "", "ST&CTL LAB 3CS-A,BELL", "ST&CTL LAB 3CS-A,BELL", "ST&CTL LAB 3CS-A,BELL", "", "", "CO 2 CS-D", "Aits051004", "D.JK"},
					{"SAT", "", "OOAD 3 CS-A", "", "", "CO 2 CS-D", "", "", "Aits051004", "D.JK"},
					{"MON", "DA  A M.TECH", "", "", "", "PP LAB 1 EEE-C,NEUMANN", "PP LAB 1 EEE-C,NEUMANN", "", "Aits051005", "KUKR"},
					{"TUE", "DA LAB M.TECH", "DA LAB M.TECH", "DA LAB M.TECH", "DA LAB M.TECH", "DAA 2CS-C", "", "DA  A M.TECH", "Aits051005", "KUKR"},
					{"WED", "", "DAA LAB 2 CS-C,BELL", "DAA LAB 2 CS-C,BELL", "DAA LAB 2 CS-C,BELL", "", "DAA 2CS-C", "", "Aits051005", "KUKR"},
					{"THU", "DAA 2CS-C", "", "DA  A M.TECH", "", "", "PP* 1 EC-C", "", "Aits051005", "KUKR"},
					{"FRI", "", "", "", "DAA 2CS-C", "DAA* 2CS-A", "", "", "Aits051005", "KUKR"},
					{"SAT", "", "", "OS* 2 CS-D", "", "", "", "DAA 2CS-C", "Aits051005", "KUKR"},
					{"MON", "SEM 3 CS-B", "", "FLAT 2 CS-B", "", "FLAT* 2 CS-A", "", "", "Aits051007", "KB"},
					{"TUE", "", "DAA LAB 2 CS-D,BELL", "DAA LAB 2 CS-D,BELL", "DAA LAB 2 CS-D,BELL", "", "FLAT 2 CS-B", "", "Aits051007", "KB"},
					{"WED", "", "JAVA LAB 2 CS-B,NEUMANN", "JAVA LAB 2 CS-B,NEUMANN", "JAVA LAB 2 CS-B,NEUMANN", "STM 3CS-A", "", "", "Aits051007", "KB"},
					{"THU", "", "FLAT 2 CS-B", "", "STM 3 CS-A", "", "", "STM 3 CS-A", "Aits051007", "KB"},
					{"FRI", "FLAT 2 CS-B", "ST&CTL LAB 3 CS-A,BELL", "ST&CTL LAB 3 CS-A,BELL", "ST&CTL LAB 3 CS-A,BELL", "", "STM 3CS-A", "", "Aits051007", "KB"},
					{"SAT", "STM 3CS-A", "", "", "FLAT 2 CS-B", "", "", "", "Aits051007", "KB"},
					{"MON", "PP LAB 1 EC-C,ARYABHATTA", "PP LAB 1 EC-C,ARYABHATTA", "PP LAB 1 EC-C,ARYABHATTA", "", "FLAT 2 CS-C", "", "", "Aits051008", "GS"},
					{"TUE", "", "", "PP 1 EC-C", "", "SEM 4 CS-A", "", "AI 3 CS-C", "Aits051008", "GS"},
					{"WED", "", "OOPC LAB 3 EE-B,SILICON", "OOPC LAB 3 EE-B,SILICON", "OOPC LAB 3 EE-B,SILICON", "", "AI 3 CS-C", "", "Aits051008", "GS"},
					{"THU", "", "", "AI 3 CS-C", "", "", "", "", "Aits051008", "GS"},
					{"FRI", "AI 3 CS-C", "", "PP 1 EC-C", "", "PP LAB 1 EC-B,ARYABHATTA", "PP LAB 1 EC-B,ARYABHATTA", "", "Aits051008", "GS"},
					{"SAT", "", "PP 1 EC-C", "", "", "AI 3 CS-C", "", "", "Aits051008", "GS"},
					{"MON", "", "JAVA LAB 2 CS-A,NEUMANN", "JAVA LAB 2 CS-A,NEUMANN", "JAVA LAB 2 CS-A,NEUMANN", "", "OOP 2CS-A", "", "Aits051010", "TNR"},
					{"TUE", "", "", "", "OOP 2CS-A", "", "", "", "Aits051010", "TNR"},
					{"WED", "OOP 2CS-A", "JAVA LAB 2 CS-B,NEUMANN", "JAVA LAB 2 CS-B,NEUMANN", "JAVA LAB 2 CS-B,NEUMANN", "", "", "", "Aits051010", "TNR"},
					{"THU", "", "", "OOP 2CS-A", "", "", "", "", "Aits051010", "TNR"},
					{"FRI", "", "JAVA LAB 2 CSD,NEUMANN", "JAVA LAB 2 CSD,NEUMANN", "JAVA LAB 2 CSD,NEUMANN", "", "", "OOP* 2CS-A", "Aits051010", "TNR"},
					{"SAT", "", "OOP 2CS-A", "", "", "", "", "", "Aits051010", "TNR"},
					{"MON", "", "DMDW 3CS-C", "", "AI 3 CS-D", "", "", "", "Aits051012", "KLNC"},
					{"TUE", "", "", "AI 3 CS-D", "", "PP LAB 1 EE-B,L1", "PP LAB 1 EE-B,L2", "", "Aits051012", "KLNC"},
					{"WED", "", "AI 3 CS-D", "", "", "SEM 3 CS-D", "", "DMDW 3CS-C", "Aits051012", "KLNC"},
					{"THU", "AI 3 CS-D", "", "", "DMDW 3CS-C", "DML LAB 3 CS-C,IBM", "DML LAB 3 CS-C,IBM", "DML LAB 3 CS-C,IBM", "Aits051012", "KLNC"},
					{"FRI", "", "", "DMDW 3CS-C", "", "OS LAB 2CS-B,SILICON", "OS LAB 2CS-B,SILICON", "OS LAB 2CS-B,SILICON", "Aits051012", "KLNC"},
					{"SAT", "DMDW 3CS-C", "SEM 3 CS-D", "", "", "AI 3CS-D", "", "", "Aits051012", "KLNC"},
					{"MON", "OOP 2 CS-D", "", "", "", "IOT LAB 3 CS-A", "IOT LAB 3 CS-A", "IOT LAB 3 CS-A", "Aits051013", "SRK"},
					{"TUE", "PP LAB 1 ME,ARYABATTA", "PP LAB 1 ME,ARYABATTA", "PP LAB 1 ME,ARYABATTA", "", "OOP 2 CS-D", "", "", "Aits051013", "SRK"},
					{"WED", "", "", "", "", "OOP 2 CS-D", "", "", "Aits051013", "SRK"},
					{"THU", "", "", "", "OOP 2CS-D", "", "", "", "Aits051013", "SRK"},
					{"FRI", "", "JAVA LAB 2CS-D,NEUMANN", "JAVA LAB 2CS-D,NEUMANN", "JAVA LAB 2CS-D,NEUMANN", "", "", "", "Aits051013", "SRK"},
					{"SAT", "", "OOP* 2 CS-D", "", "", "", "OOP 2 CS-D", "", "Aits051013", "SRK"},
					{"MON", "", "PP* 1 CSE-A", "", "AI* 3 CSE-D", "OOP 2 CSE-C", "", "", "Aits051014", "CVLN"},
					{"TUE", "", "PP* 1 CSE-A", "", "", "PP LAB 1 CSE-A,NEUMANN", "PP LAB 1 CSE-A,NEUMANN", "", "Aits051014", "CVLN"},
					{"WED", "", "PP* 1 EEE-C", "", "", "", "", "OOP 2 CSE-C", "Aits051014", "CVLN"},
					{"THU", "", "OOP 2 CSE-C", "", "DMDW* 3 CSE-C", "JAVA LAB 2 CSE-C NEUMANN", "JAVA LAB 2 CSE-C NEUMANN", "JAVA LAB 2 CSE-C NEUMANN", "Aits051014", "CVLN"},
					{"FRI", "OOP 2 CSE-C", "", "", "", "", "OOP 2 CSE-C", "", "Aits051014", "CVLN"},
					{"SAT", "", "OOP* 2 CSE-C", "", "", "", "SEM 1 CSE-A", "", "Aits051014", "CVLN"},
					{"MON", "OS 2 CSE-A", "JAVA LAB 2 CSE-A NEUMANN", "JAVA LAB 2 CSE-A NEUMANN", "JAVA LAB 2 CSE-A NEUMANN", "", "PP 1 CSE-D", "", "Aits051015", "NVC"},
					{"TUE", "", "OS 2 CSE-A", "", "", "", "", "DAA* 2 CSE-B", "Aits051015", "NVC"},
					{"WED", "", "OS 2 CSE-A", "", "", "", "", "", "Aits051015", "NVC"},
					{"THU", "PP LAB 1 CSE-D NEUMANN", "PP LAB 1 CSE-D NEUMANN", "PP LAB 1 CSE-D NEUMANN", "", "", "OS 2 CSE-A", "", "Aits051015", "NVC"},
					{"FRI", "", "OS LAB 2 CSE-A SILICON", "OS LAB 2 CSE-A SILICON", "OS LAB 2 CSE-A SILICON", "", "OOAD* 3 CSE-C", "", "Aits051015", "NVC"},
					{"SAT", "", "", "PP 1 CSE-D", "", "OS 2 CSE-A", "", "", "Aits051015", "NVC"},
					{"MON", "", "OS LAB 2 CSE-C SILICON", "OS LAB 2 CSE-C SILICON", "OS LAB 2 CSE-C SILICON", "", "OS 2 CSE-C", "", "Aits051016", "SAB"},
					{"TUE", "", "OOAD 3 CSE-D", "", "OS 2 CSE-C", "ST&CT LAB 3 CSE-D SILICON", "ST&CT LAB 3 CSE-D SILICON", "ST&CT LAB 3 CSE-D SILICON", "Aits051016", "SAB"},
					{"WED", "", "", "OOAD 3 CSE-D", "", "OS 2 CSE-C", "", "", "Aits051016", "SAB"},
					{"THU", "PP* 1 EE-B", "", "", "", "OOAD 3 CSE-D", "", "", "Aits051016", "SAB"},
					{"FRI", "OOAD 3 CSE-D", "OS LAB 2 CSE-A SILICON", "OS LAB 2 CSE-A SILICON", "OS LAB 2 CSE-A SILICON", "", "", "OS 2 CSE-C", "Aits051016", "SAB"},
					{"SAT", "OS 2 CSE-C", "", "PP* 1 ME", "", "", "OOAD 3 CSE-D", "", "Aits051016", "SAB"},
					{"MON", "", "PP 1 ECE-D", "", "", "PP LAB 1 ECE-D ARYABATTA", "PP LAB 1 ECE-D ARYABATTA", "", "Aits051017", "ARB"},
					{"TUE", "PP 1 ECE-D", "", "DAA 2 CSE-A", "", "", "", "DAA 2CS-A", "Aits051017", "ARB"},
					{"WED", "", "", "PP* 1 EEE-A", "", "DAA LAB 2 CSE-A BELL", "DAA LAB 2 CSE-A BELL", "DAA LAB 2 CSE-A BELL", "Aits051017", "ARB"},
					{"THU", "DAA 2 CSE-A", "DM LAB 3 CSE-D IBM", "DM LAB 3 CSE-D IBM", "DM LAB 3 CSE-D IBM", "", "PP 1 ECE-D", "", "Aits051017", "ARB"},
					{"FRI", "", "PP 1 ECE-D", "", "", "DAA 2 CSE-A", "", "", "Aits051017", "ARB"},
					{"SAT", "", "", "DAA 2 CSE-A", "", "SEM 2 CSE-B", "", "", "Aits051017", "ARB"},
					{"MON", "", "OOP 2 CSE-B", "", "DAA 2 CSE-D", "", "SPORTS 1 CSE-D", "", "Aits051018", "MNP"},
					{"TUE", "OOP 2 CSE-B", "DAA LAB 2 CSE-D BELL", "DAA LAB 2 CSE-D BELL", "DAA LAB 2 CSE-D BELL", "", "DAA 2 CSE-D", "", "Aits051018", "MNP"},
					{"WED", "DAA 2 CSE-D", "JAVA LAB 2 CSE-B NEUMANN", "JAVA LAB 2 CSE-B NEUMANN", "JAVA LAB 2 CSE-B NEUMANN", "", "", "OOP 2 CSE-B", "Aits051018", "MNP"},
					{"THU", "", "DAA 2 CSE-D", "", "OOP 2 CSE-B", "OOP 2 CSE-B", "", "", "Aits051018", "MNP"},
					{"FRI", "", "", "", "", "PP LAB 1 ECE-B ARYABATTA", "PP LAB 1 ECE-B ARYABATTA", "", "Aits051018", "MNP"},
					{"SAT", "", "", "OOP 2 CSE-B", "", "", "", "DAA 2 CSE-D", "Aits051018", "MNP"},
					{"MON", "PP 1 ECE-A", "", "", "", "", "", "", "Aits051019", "NP"},
					{"TUE", "", "", "SEM 2 CSE-C", "", "PP LAB 1 CSE-A NEUMANN", "PP LAB 1 CSE-A NEUMANN", "", "Aits051019", "NP"},
					{"WED", "MOOC 3 CSE-B", "", "PP* 1 ECE-A", "", "PP LAB 1 CSE-C NEUMANN", "PP LAB 1 CSE-C NEUMANN", "", "Aits051019", "NP"},
					{"THU", "PP 1 ECE-A", "", "", "", "PP LAB 1 ECE-A ARYABATTA", "PP LAB 1 ECE-A ARYABATTA", "MOOC 3 CSE-B", "Aits051019", "NP"},
					{"FRI", "", "OS LAB 2 CSE-A SILICON", "OS LAB 2 CSE-A SILICON", "OS LAB 2 CSE-A SILICON", "", "", "", "Aits051019", "NP"},
					{"SAT", "", "PP 1 ECE-A", "", "", "", "", "MOOC 3 CSE-B", "Aits051019", "NP"},
					{"MON", "MOOC 3 CSE-C", "", "", "IOT 3 CSE-A", "IOT LAB 3 CSE-A IOT", "IOT LAB 3 CSE-A IOT", "IOT LAB 3 CSE-A IOT", "Aits051021", "JMNP"},
					{"TUE", "PP LAB 1 ME ARYABATTA", "PP LAB 1 ME ARYABATTA", "PP LAB 1 ME ARYABATTA", "", "", "SPORTS 1 CSE-C", "", "Aits051021", "JMNP"},
					{"WED", "IOT 3 CSE-A", "", "", "", "SEM 4 CSE-B", "", "", "Aits051021", "JMNP"},
					{"THU", "", "", "IOT 3 CSE-A", "", "IOT LAB 3 CSE-C IOT", "IOT LAB 3 CSE-C IOT", "IOT LAB 3 CSE-C IOT", "Aits051021", "JMNP"},
					{"FRI", "STM* 3 CSE-B", "", "", "MOOC 3 CSE-C", "IOT 3 CSE-A", "", "", "Aits051021", "JMNP"},
					{"SAT", "", "", "SEM 3 CSE-A", "", "", "", "MOOC 3 CSE-C", "Aits051021", "JMNP"},
					{"MON", "", "AI 3 CSE-A", "", "IOT 3 CSE-B", "", "", "", "Aits051023", "AVK"},
					{"TUE", "", "ST&CT LAB 3 CSE-C SILICON", "ST&CT LAB 3 CSE-C SILICON", "ST&CT LAB 3 CSE-C SILICON", "", "AI 3 CSE-A", "", "Aits051023", "AVK"},
					{"WED", "", "IOT LAB 3 CSE-B IOT", "IOT LAB 3 CSE-B IOT", "IOT LAB 3 CSE-B IOT", "SEM 4 CSE-B", "SEM 4 CSE-B", "", "Aits051023", "AVK"},
					{"THU", "IOT 3 CSE-B", "IOT LAB 3 CSE-D IOT", "IOT LAB 3 CSE-D IOT", "IOT LAB 3 CSE-D IOT", "", "AI 3 CSE-A", "", "Aits051023", "AVK"},
					{"FRI", "AI 3 CSE-A", "", "IOT 3 CSE-B", "", "", "", "", "Aits051023", "AVK"},
					{"SAT", "", "IOT 3 CSE-B", "", "", "AI 3 CSE-A", "", "CO* 2 CSE-B", "Aits051023", "AVK"},
					{"MON", "IOT 3 CSE-D", "", "SA 4 CSE-A", "", "DAA LAB 2 CSE-B BELL", "DAA LAB 2 CSE-B BELL", "DAA LAB 2 CSE-B BELL", "Aits051024", "CNS"},
					{"TUE", "", "SA 4 CSE-A", "", "SA 4 CSE-A", "SEMINAR 4 CSE-A", "SEMINAR 4 CSE-A", "", "Aits051024", "CNS"},
					{"WED", "SA 4 CSE-A", "IOT LAB 3 CSE-B IOT", "IOT LAB 3 CSE-B IOT", "IOT LAB 3 CSE-B IOT", "", "", "IOY 3 CSE-D", "Aits051024", "CNS"},
					{"THU", "", "IOT LAB 3 CSE-D IOT", "IOT LAB 3 CSE-D IOT", "IOT LAB 3 CSE-D IOT", "", "IOT 3 CSE-D", "", "Aits051024", "CNS"},
					{"FRI", "", "", "IOT 3 CSE-D", "", "OOPC* 3 EC-B", "", "", "Aits051024", "CNS"},
					{"SAT", "", "", "", "IOT 3 CSE-D", "SEM 2 CS-B", "", "", "Aits051024", "CNS"},
					{"MON", "", "AI 3 CSE-B", "", "", "PP LAB 1 EEE-C,NEUMANN", "PP LAB 1 EEE-C,NEUMANN", "", "Aits051025", "TNL"},
					{"TUE", "AIT W/S   I CS-D IOT", "AIT W/S   I CS-D IOT", "AIT W/S   I CS-D IOT", "", "AI* 3 CSE-A", "AI* 3 CSE-A", "", "Aits051025", "TNL"},
					{"WED", "", "", "SEM 1 CS-B", "", "OOPC LAB 3 EC-C SILICON", "OOPC LAB 3 EC-C SILICON", "OOPC LAB 3 EC-C SILICON", "Aits051025", "TNL"},
					{"THU", "", "", "AI 3 CSE-B", "", "AI 3 CSE-B", "", "", "Aits051025", "TNL"},
					{"FRI", "", "AI 3 CSE-B", "AI 3 CSE-B", "AI 3 CSE-B", "AIT W/S  1 CS-C IOT", "AIT W/S  1 CS-C IOT", "", "Aits051025", "TNL"},
					{"SAT", "", "", "SEM 3 CSE-A", "", "AI 3 CSE-B", "SEM 3 CSE-A", "", "Aits051025", "TNL"},
					{"MON", "AIT W/S 1 CS-C  IOT", "AIT W/S 1 CS-C  IOT", "AIT W/S 1 CS-C  IOT", "", "FLAT 2 CSE-D", "", "", "Aits051026", "RAK"},
					{"TUE", "AIT W/S 1 CS-D  IOT", "AIT W/S 1 CS-D  IOT", "AIT W/S 1 CS-D  IOT", "", "", "OOAD* 3 CSE-B", "", "Aits051026", "RAK"},
					{"WED", "", "", "FLAT 2 CSE-D", "", "PP LAB 1 CE ARYABATTA", "PP LAB 1 CE ARYABATTA", "", "Aits051026", "RAK"},
					{"THU", "", "", "FLAT 2 CSE-D", "", "", "SPORTS 1 CS-B", "", "Aits051026", "RAK"},
					{"FRI", "IT W/S 1 CE IOT", "IT W/S 1 CE IOT", "IT W/S 1 CE IOT", "", "FLAT 2 CSE-D", "FLAT 2 CSE-D", "", "Aits051026", "RAK"},
					{"SAT", "FLAT 2 CSE-D", "", "SEM 3 CSSE-B", "", "OS* 2 CSE-A", "OS* 2 CSE-A", "OS* 2 CSE-A", "Aits051026", "RAK"},
					{"MON", "DP 4CSE-B", "", "", "DP 4CSE-B", "OOPC LAB 3EE-B SILICON", "OOPC LAB 3EE-B SILICON", "OOPC LAB 3EE-B SILICON", "Aits051028", "BNK"},
					{"TUE", "", "DP 4CSE-B", "", "STM* 3CSE-D", "", "OOAD 3CSE-B", "", "Aits051028", "BNK"},
					{"WED", "", "", "DP 4CSE-B", "", "", "OOAD 3CSE-B", "", "Aits051028", "BNK"},
					{"THU", "", "OOAD 3CSE-B", "", "", "PP LAB 1EC-A ARYABATTA", "PP LAB 1EC-A ARYABATTA", "PP LAB 1EC-A ARYABATTA", "Aits051028", "BNK"},
					{"FRI", "", "OOAD 3CSE-B", "OOAD 3CSE-B", "OOAD 3CSE-B", "ST&CT LAB 3CSE-B BELL", "ST&CT LAB 3CSE-B BELL", "ST&CT LAB 3CSE-B BELL", "Aits051028", "BNK"},
					{"SAT", "OOAD 3CSE-B", "", "", "SEM 3CSE-B", "", "SEM 3CSE-A", "", "Aits051028", "BNK"},
					{"MON", "SEM 3CSE-B", "", "DMDW 3CSE-B", "", "PP LAB 1EC-D ARYABATTA", "PP LAB 1EC-D ARYABATTA", "", "Aits051029", "SMR"},
					{"TUE", "", "", "SEM 2CSE-C", "", "DMDW 3CSE-B", "", "", "Aits051029", "SMR"},
					{"WED", "", "DM LAB 3 CSE-B IBM", "DM LAB 3 CSE-B IBM", "DM LAB 3 CSE-B IBM", "", "", "DMDW 3CSE-B", "Aits051029", "SMR"},
					{"THU", "PP LAB 1CS-D NEUMANN", "PP LAB 1CS-D NEUMANN", "PP LAB 1CS-D NEUMANN", "PP LAB 1CS-D NEUMANN", "", "DMDW 3CSE-B", "", "Aits051029", "SMR"},
					{"FRI", "", "JAVA LAB 2CSE-D NEUMANN", "JAVA LAB 2CSE-D NEUMANN", "JAVA LAB 2CSE-D NEUMANN", "", "", "", "Aits051029", "SMR"},
					{"SAT", "", "", "DMDW 3CSE-B", "SEM 3CSE-B", "", "", "", "Aits051029", "SMR"},
					{"MON", "", "DP 4CSE-A", "", "", "OOPC 3 ECE-A", "", "", "Aits051030", "RRP"},
					{"TUE", "DP 4CSE-A", "OOPC LAB 3 ECE-A NEUMANN", "OOPC LAB 3 ECE-A NEUMANN", "OOPC LAB 3 ECE-A NEUMANN", "", "OOPC 3 ECE-A", "", "Aits051030", "RRP"},
					{"WED", "", "DP 4 CSE-A", "", "DP 4 CSE-A", "OOPC LAB 3 ECE-C SILICON", "OOPC LAB 3 ECE-C SILICON", "OOPC LAB 3 ECE-C SILICON", "Aits051030", "RRP"},
					{"THU", "", "OOPC 3 ECE-A", "", "", "", "", "SEM 2 CSE-A", "Aits051030", "RRP"},
					{"FRI", "", "", "OOPC 3 ECE-A", "", "AIT W/S 1 CSE-C IOT", "AIT W/S 1 CSE-C IOT", "", "Aits051030", "RRP"},
					{"SAT", "OOPC 3 ECE-A", "SEM 3 CSE-D", "", "", "", "OOP* 2 CSE-D", "", "Aits051030", "RRP"},
					{"MON", "OOPC 3 EE-C", "OOPC LAB 3EE-C SILICON", "OOPC LAB 3EE-C SILICON", "OOPC LAB 3EE-C SILICON", "", "", "OS 2CSE-D", "Aits051031", "ONR"},
					{"TUE", "", "OOPC LAB 3EC-A NEUMANN", "OOPC LAB 3EC-A NEUMANN", "OOPC LAB 3EC-A NEUMANN", "", "OOPC 3 EE-C", "", "Aits051031", "ONR"},
					{"WED", "", "OS 2CSE-D", "", "", "SEM 4CSE-A", "", "", "Aits051031", "ONR"},
					{"THU", "OS 2CSE-D", "", "OOPC 3EE-C", "", "OS LAB 2CSE-D SILICON", "OS LAB 2CSE-D SILICON", "OS LAB 2CSE-D SILICON", "Aits051031", "ONR"},
					{"FRI", "", "OOPC 3EE-C", "", "", "", "OS 2CSE-D", "", "Aits051031", "ONR"},
					{"SAT", "", "", "OS 2CSE-D", "", "OOPC* 3 EEE-C", "", "", "Aits051031", "ONR"},
					{"MON", "PP LAB 1 ECE-C ARYABATTA", "PP LAB 1 ECE-C ARYABATTA", "PP LAB 1 ECE-C ARYABATTA", "", "", "", "", "Aits051032", "MA"},
					{"TUE", "PP 1 EEE-B", "", "OOPC 3 ECE-C", "", "PP LAB 1 EEE-B ARYABATTA", "PP LAB 1 EEE-B ARYABATTA", "", "Aits051032", "MA"},
					{"WED", "", "", "", "", "OOPC LAB 3 ECE-C SILICON", "OOPC LAB 3 ECE-C SILICON", "OOPC LAB 3 ECE-C SILICON", "Aits051032", "MA"},
					{"THU", "PP 1 EEE-B", "", "", "OOPC 3 ECE-C", "", "SPORTS 1 CSE-A", "", "Aits051032", "MA"},
					{"FRI", "", "PP 1 EEE-B", "", "", "", "OOPC 3 ECE-C", "", "Aits051032", "MA"},
					{"SAT", "OOPC 3 ECE-C", "", "PP 1 EEE-B", "", "OOPC 3 ECE-C", "", "", "Aits051032", "MA"},
					{"MON", "SA 4 CSE-C", "", "SA 4 CSE-C", "", "SEM 4 CSE-C", "SEM 4 CSE-C", "", "Aits051033", "DS"},
					{"TUE", "", "SA 4 CSE-C", "", "SEM 2 CSE-B", "OOPC LAB 3 ECE-D IBM", "OOPC LAB 3 ECE-D IBM", "OOPC LAB 3 ECE-D IBM", "Aits051033", "DS"},
					{"WED", "", "SA 4 CSE-C", "", "", "PP LAB 1 CE ARYABATTA", "PP LAB 1 CE ARYABATTA", "", "Aits051033", "DS"},
					{"THU", "", "", "", "", "", "", "DMOW* 3 CSE-D", "Aits051033", "DS"},
					{"FRI", "", "PP* 1 ECE-D", "", "MOOC 3 CSE-C", "", "", "", "Aits051033", "DS"},
					{"SAT", "AIT W/S 1 CSE-A IOT", "AIT W/S 1 CSE-A IOT", "AIT W/S 1 CSE-A IOT", "", "", "", "MOOC 3 CSE-C", "Aits051033", "DS"},
					{"MON", "PP 1 ME", "", "PP 1 CE", "", "PP 1 CE", "", "", "Aits051034", "BVS"},
					{"TUE", "PP LAB 1 ME ARYABATTA", "PP LAB 1 ME ARYABATTA", "PP LAB 1 ME ARYABATTA", "", "", "SEM 4 CSE-A", "", "Aits051034", "BVS"},
					{"WED", "PP 1 CE", "", "SEM 1 CSE-D", "", "PP LAB 1 CE ARYABATTA", "PP LAB 1 CE ARYABATTA", "", "Aits051034", "BVS"},
					{"THU", "", "", "", "", "", "PP 1 ME", "", "Aits051034", "BVS"},
					{"FRI", "", "", "", "", "PP LAB 1 CSE-B NEUMANN", "PP LAB 1 CSE-B NEUMANN", "", "Aits051034", "BVS"},
					{"SAT", "", "", "PP 1 ME ", "", "", "", "", "Aits051034", "BVS"},
					{"MON", "", "SEM 2 CSE-D", "", "STM 3 CSE-C", "DAA LAB 2 CSE-B BELL", "DAA LAB 2 CSE-B BELL", "DAA LAB 2 CSE-B BELL", "Aits051035", "VM"},
					{"TUE", "STM 3 CSE-C ", "ST&CT LAB 3 CSE-C SILICON", "ST&CT LAB 3 CSE-C SILICON", "ST&CT LAB 3 CSE-C SILICON", "", "", "", "Aits051035", "VM"},
					{"WED", "", "DAA LAB 2 CSE-C BELL", "DAA LAB 2 CSE-C BELL", "DAA LAB 2 CSE-C BELL", "STM 3 CSE-C ", "", "SEM 2 CSE--D", "Aits051035", "VM"},
					{"THU", "STM 3 CSEC ", "", "", "", "", "", "", "Aits051035", "VM"},
					{"FRI", "IT W/S 1 CE IOT", "IT W/S 1 CE IOT", "IT W/S 1 CE IOT", "", "STM 3 CSE-C ", "", "", "Aits051035", "VM"},
					{"SAT", "", "", "LAF 1 CSE-D", "", "", "OOAD* 3 CSE-D", "", "Aits051035", "VM"},
					{"MON", "AIT W/S 1 CS-B IOT", "AIT W/S 1 CS-B IOT", "AIT W/S 1 CS-B IOT", "", "", "", "", "Aits051036", "CSD"},
					{"TUE", "CO 2CSE-A", "OOPC LAB 3 ECE-A NEUMANN", "OOPC LAB 3 ECE-A NEUMANN", "OOPC LAB 3 ECE-A NEUMANN", "", "FLAT 2CSE-C", "", "Aits051036", "CSD"},
					{"WED", "FLAT 2CSE-C", "", "", "CO 2CSE-A", "DAA LAB 2CSE-A BELL", "DAA LAB 2CSE-A BELL", "DAA LAB 2CSE-A BELL", "Aits051036", "CSD"},
					{"THU", "", "", "FLAT 2CSE-C", "", "CO 2CSE-A", "", "SEM 2CSE-A", "Aits051036", "CSD"},
					{"FRI", "", "FLAT 2CSE-C", "", "", "", "CO 2 CSE-A", "", "Aits051036", "CSD"},
					{"SAT", "SEM 2CSE-A", "", "", "FLAT 2CSE-C", "", "", "CO 2CSE-A", "Aits051036", "CSD"},
					{"MON", "", "SEM 2CSE-D", "", "", "PP LAB 1 EEE-C NEUMANN", "PP LAB 1 EEE-C NEUMANN", "", "Aits051037", "DB"},
					{"TUE", "", "", "", "", "", "", "", "Aits051037", "DB"},
					{"WED", "PP 1 EEE-C", "OOPC LAB 3 CSE-B SILICON", "OOPC LAB 3 CSE-B SILICON", "OOPC LAB 3 CSE-B SILICON", "", "", "IOT* 3 CSE-D", "Aits051037", "DB"},
					{"THU", "", "", "PP 1 EEE-C", "", "DM LAB 3 CSE-C IBM", "DM LAB 3 CSE-C IBM", "DM LAB 3 CSE-C IBM", "Aits051037", "DB"},
					{"FRI", "", "", "", "", "ST&CT LAB 3 CSE-B BELL", "ST&CT LAB 3 CSE-B BELL", "ST&CT LAB 3 CSE-B BELL", "Aits051037", "DB"},
					{"SAT", "LAF 1 CSE-B", "", "", "", "PP 1 EEE-C", "", "", "Aits051037", "DB"},
					{"MON", "", "DMDW 3 CSE-D", "", "", "DAA LAB 2 CSE-B BELL", "DAA LAB 2 CSE-B BELL", "DAA LAB 2 CSE-B BELL", "Aits051038", "TSL"},
					{"TUE", "DMDW 3 CSE-D", "DAA LAB 2 CSE-D BELL", "DAA LAB 2 CSE-D BELL", "DAA LAB 2 CSE-D BELL", "", "", "DAA 2 CSE-B", "Aits051038", "TSL"},
					{"WED", "PP* 1 CE", "", "", "DMDW 3 CSE-D ", "DAA 2 CSE-B", "", "SEM 2 CSE-B", "Aits051038", "TSL"},
					{"THU", "DAA 2 CSE-B", "DAA LAB 3 CSE-D IBM", "DAA LAB 3 CSE-D IBM", "DAA LAB 3 CSE-D IBM", "", "", "DMDW 3 CSE-D", "Aits051038", "TSL"},
					{"FRI", "", "", "", "DAA 2 CSE-B", "", "", "", "Aits051038", "TSL"},
					{"SAT", "SEM 2 CSE-A", "", "DMDW 3 CSE-D", "", "", "DAA 2 CSE-B", "", "Aits051038", "TSL"},
					{"MON", "", "OOPC 3 EEE-A", "", "IOT* 3 CSE-A", "OOPC 3 ECE-D", "", "", "Aits051039", "JK"},
					{"TUE", "OOPC 3 ECE-D", "", "OOPC 3 EEE-A", "", "OOPC LAB 3 ECE-D IBM", "OOPC LAB 3 ECE-D IBM", "OOPC LAB 3 ECE-D IBM", "Aits051039", "JK"},
					{"WED", "", "OOPC 3 EEE-A", "", "", "SEM 4 CSE-B", "", "", "Aits051039", "JK"},
					{"THU", "", "", "OOPC 3 ECE-D", "", "JAVA LAB 2 CSE-C NEUMANN", "JAVA LAB 2 CSE-C NEUMANN", "JAVA LAB 2 CSE-C NEUMANN", "Aits051039", "JK"},
					{"FRI", "OOPC 3 EEE-A", "OOPC LAB 3 EEE-A SILICON", "OOPC LAB 3 EEE-A SILICON", "OOPC LAB 3 EEE-A SILICON", "", "OOPC 3 ECE-D", "", "Aits051039", "JK"},
					{"SAT", "", "OOPC 3 ECE-D", "", "", "OOPC 3 EEE-A", "", "", "Aits051039", "JK"},
					{"MON", "CO 2 CS-B", "", "FLAT* 2 CS-B", "", "OOPC LAB 3 EE-B SILICON", "OOPC LAB 3 EE-B SILICON", "OOPC LAB 3 EE-B SILICON", "Aits051009", "DSSR"},
					{"TUE", "", "CO 2 CS-B", "", "SEM 2 CS-B", "", "", "OOPC 3 EE-B", "Aits051009", "DSSR"},
					{"WED", "PP* 1 CS-C", "", "OOPC 3 EE-B", "", "", "CO 2 CS-B", "", "Aits051009", "DSSR"},
					{"THU", "PP*1 EC-B", "", "CO 2 CS-B", "", "", "OOPC 3 EEE-B", "", "Aits051009", "DSSR"},
					{"FRI", "", "", "", "OOPC 3 EE-B", "OS LAB 2 CS-B SILICON", "OS LAB 2 CS-B SILICON", "OS LAB 2 CS-B SILICON", "Aits051009", "DSSR"},
					{"SAT", "OOPC 3 EE-B", "", "", "", "SEM 2 CS-B", "", "CO 2 CS-B", "Aits051009", "DSSR"},
					{"MON", "PP LAB 1 EC-C ARYABATTA", "PP LAB 1 EC-C ARYABATTA", "PP LAB 1 EC-C ARYABATTA", "", "FLAT 2 CS-A", "", "", "Aits051011", "BPRR"},
					{"TUE", "", "", "OS 2 CS-B", "", "FLAT 2 CS-A", "", "SEM 2 CS-C", "Aits051011", "BPRR"},
					{"WED", "OS 2 CS-B", "DAA LAB 2 CS-C,BELL", "DAA LAB 2 CS-C,BELL", "DAA LAB 2 CS-C,BELL", "", "", "DMDW* 3 CS-A", "Aits051011", "BPRR"},
					{"THU", "", "", "", "FLAT 2 CS-A", "", "OS 2 CS-B", "", "Aits051011", "BPRR"},
					{"FRI", "FLAT 2 CS-A", "", "OS 2 CS-B", "", "OS LAB 2 CS-B SILICON", "OS LAB 2 CS-B SILICON", "OS LAB 2 CS-B SILICON", "Aits051011", "BPRR"},
					{"SAT", "", "OS 2 CS-B", "", "", "", "FLAT 2 CS-A", "", "Aits051011", "BPRR"},
					{"MON", "LAF 1 CS-A", "OS LAB 2 CS-C SILICON", "OS LAB 2 CS-C SILICON", "OS LAB 2 CS-C SILICON", "", "PP 1 CS-C", "", "Aits051006", "DKR"},
					{"TUE", "", "", "OOP* 2 CS-A", "", "", "", "MOOC 3 CS-A", "Aits051006", "DKR"},
					{"WED", "PP* 1 CS-C", "", "", "", "PP LAB 1 CS-C NEUMANN", "PP LAB 1 CS-C NEUMANN", "", "Aits051006", "DKR"},
					{"THU", "MOOC 3 CS-A", "", "PP 1 CS-C", "", "DMDW* 3 CS-A", "", "", "Aits051006", "DKR"},
					{"FRI", "", "OOPC LAB 3 EE-A IBM", "OOPC LAB 3 EE-A IBM", "OOPC LAB 3 EE-A IBM", "", "", "", "Aits051006", "DKR"},
					{"SAT", "", "IOT* 3 CSE-B", "", "", "", "", "MOOC 3 CS-A", "Aits051006", "DKR"},
					{"MON", "", "OOPC LAB 3 EE-C IBM", "OOPC LAB 3 EE-C IBM", "OOPC LAB 3 EE-C IBM", "", "", "", "Aits051020", "RM"},
					{"TUE", "CO*2 CS-D", "", "OOPC 3 EC-B", "", "IOT 3 CS-C", "", "", "Aits051020", "RM"},
					{"WED", "IOT 3 CS-C ", "OOPC LAB 3 EC-C SILICON", "OOPC LAB 3 EC-C SILICON", "OOPC LAB 3 EC-C SILICON", "", "OOPC 3 EC-B", "", "Aits051020", "RM"},
					{"THU", "OOPC 3 EC-B", "", "", "", "IOT LAB 3 CS-C IOT", "IOT LAB 3 CS-C IOT", "IOT LAB 3 CS-C IOT", "Aits051020", "RM"},
					{"FRI", "", "IOT 3 CS-C", "", "", "OOPC 3 EC-B", "", "IOT 3 CS-C", "Aits051020", "RM"},
					{"SAT", "", "OOPC* 2 CSE-C ", "", "OOPC 3 EC-B", "", "IOT 3 CS-C", "", "Aits051020", "RM"},
					{"MON", "", "", "STM 3 CS-D", "", "PP LAB 1 EC-D ARYABATTA", "PP LAB 1 EC-D ARYABATTA", "", "Aits051022", "KAK"},
					{"TUE", "", "", "", "STM 3 CS-D", "ST&CT LAB 3 CS-D, SILICON", "ST&CT LAB 3 CS-D,SILICON", "ST&CT LAB 3 CS-D,SILICON", "Aits051022", "KAK"},
					{"WED", "", "", "SEM 3 CS-C", "SEM 3 CS-C", "", "STM 3 CS-D", "", "Aits051022", "KAK"},
					{"THU", "", "", "FLAT* 2 CS-C", "", "", "", "", "Aits051022", "KAK"},
					{"FRI", "", "STM 3 CS-D", "", "", "PP LAB 1 CS-B, NEUMANN", "PP LAB 1 CS-B, NEUMANN", "", "Aits051022", "KAK"},
					{"SAT", "STM 3 CS-D", "", "", "", "", "", "", "Aits051022", "KAK"},
				},
				new String[] {
					"Days", "1[9.15-10.10]", "2[10.10-11.05]", "3[11.05-12.00]", "4[12.00-12.55]", "5[2.00-2.55]", "6[2.55-3.50]", "7[3.50-5.00]", "Emp_id", "Emp_Name"
				}
			));
			table.getColumnModel().getColumn(1).setPreferredWidth(115);
			table.getColumnModel().getColumn(2).setPreferredWidth(154);
			table.getColumnModel().getColumn(3).setPreferredWidth(168);
			table.getColumnModel().getColumn(4).setPreferredWidth(154);
			table.getColumnModel().getColumn(5).setPreferredWidth(116);
			table.getColumnModel().getColumn(6).setPreferredWidth(114);
			table.getColumnModel().getColumn(7).setPreferredWidth(116);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		JLabel lblSearch = new JLabel("Search Emp_id");
		lblSearch.setForeground(Color.ORANGE);
		lblSearch.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblSearch.setBounds(76, 206, 134, 19);
		contentPane.add(lblSearch);
		
		JButton cancel = new JButton("Cancel");
		cancel.setFont(new Font("Tahoma", Font.BOLD, 13));
		cancel.setForeground(Color.ORANGE);
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				contentPane.setVisible(false);
	            new details();
			}
		});
		cancel.setBounds(595, 206, 89, 23);
		contentPane.add(cancel);
		
		textFieldsearch = new JTextField();
		textFieldsearch.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				try {
					conn con = new conn();
		            String str = "select * from CSE_FACULTY where Emp_id='"+textFieldsearch.getText()+"'";
		            ResultSet rs= con.s.executeQuery(str);
					table.setModel(DbUtils.resultSetToTableModel(rs));
					
				}
				catch(Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		textFieldsearch.setBounds(267, 207, 86, 20);
		contentPane.add(textFieldsearch);
		textFieldsearch.setColumns(10);
		
		JLabel days = new JLabel("Search Day");
		days.setForeground(Color.ORANGE);
		days.setFont(new Font("Tahoma", Font.BOLD, 15));
		days.setBounds(76, 256, 107, 23);
		contentPane.add(days);
		
		field = new JTextField();
		field.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				try {
					conn con = new conn();
		            String str = "select * from CSE_FACULTY where Days='"+field.getText()+"'";
		            ResultSet rs= con.s.executeQuery(str);
					table.setModel(DbUtils.resultSetToTableModel(rs));
					
				}
				catch(Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		field.setBounds(267, 259, 86, 20);
		contentPane.add(field);
		field.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Search Name");
		lblNewLabel.setForeground(Color.ORANGE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(76, 318, 134, 14);
		contentPane.add(lblNewLabel);
		
		Field1 = new JTextField();
		Field1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				try {
					conn con = new conn();
		            String str = "select * from CSE_FACULTY where Emp_Name='"+Field1.getText()+"'";
		            ResultSet rs= con.s.executeQuery(str);
					table.setModel(DbUtils.resultSetToTableModel(rs));
					
				}
				catch(Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		Field1.setBounds(267, 315, 86, 20);
		contentPane.add(Field1);
		Field1.setColumns(10); 
		
		lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("D:\\Flat\\fancy-rings-motion-background-flat-design-4k-and-full-hd-blue_htrkjm1f__F0003.png"));
		lblNewLabel_1.setBounds(0, 0, 1500,720);
		contentPane.add(lblNewLabel_1);
	}
}
